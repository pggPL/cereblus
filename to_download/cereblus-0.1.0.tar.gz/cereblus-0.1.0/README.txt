Celerbus is a package to create simple neural network simulations.

For more info visit
https://github.com/pggPL/cereblus